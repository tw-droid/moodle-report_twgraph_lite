<?php
 
 $string['pluginname'] = 'TWGraph_Lite';

?>
