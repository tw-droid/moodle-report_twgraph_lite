<?php

$plugin->component = 'report_twgraph_lite';
$plugin->version = 2025110200;
$plugin->release = 'v1.0';

?>
